package java_final_homework;

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.util.Calendar;

public class MyNote extends JFrame
{
   private static final long serialVersionUID = 1L;

   private JTextArea JA1 = new JTextArea(140,40);
   private JTextArea JA2 = new JTextArea(140,40);
   private JLabel JL1 = new JLabel("");
   private JLabel JL2 = new JLabel("");
   private JTextPane JTP;

   private StringBuffer SB;  
   
   class MyDialog extends JDialog
   {
      private static final long serialVersionUID = 1L;
      
      public MyDialog(JFrame JF,String Str)
      {   
    	 this.setTitle("Jave 3�й� 2014211447 �ȼ�ȣ");
    	 JTP = new JTextPane();
    	 JTP.setBounds(13, 15, 250, 220);
 
         JPanel JP = new JPanel();
         JP.setBounds(0, 0, 500, 500);
         JP.setLayout(null);
         
         Border Bor = BorderFactory.createTitledBorder("�޷�");
         JP.setBorder(Bor);
        
         JP.add(JTP);
         setCalendar();
         
         add(JP);
         setSize(300,300);
      }
   }
   public void setCalendar()
   {
	  Calendar cal= Calendar.getInstance();
      int today = cal.get(Calendar.DATE);
      cal.set(Calendar.DATE,1);
      int nowYear = cal.get(Calendar.YEAR);
      int nowMonth = cal.get(Calendar.MONTH);
      int sDayNum = cal.get(Calendar.DAY_OF_WEEK);
      int endDate = cal.getActualMaximum(Calendar.DATE);
      int sDay = sDayNum;
      
      SB = new StringBuffer();
       
      SB.append("=========== "+ nowYear+"��  " + (nowMonth+1) + "�� ============\n");
      SB.append("    ��       ��       ȭ       ��       ��       ��       ��       \n");
          for (int i=1; i<sDayNum;i++)
          {
        	  SB.append("           ");
          }
          for (int i = 1; i <= endDate ; i++) 
          {        
              if(i==today)
              {
            	  SB.append("  ["+i+"]    "+""); 
              }
              else 
              {
            	  if(i>=10)
            	  {
            		  SB.append("   "+i+"   ");
            	  }
            	  else
            	  {
            		  SB.append("   "+i+"      ");
            	  }
              }
              if(sDay%7==0)
              {
            	  SB.append("\n"); 
              }
              sDay++;
          }
          JTP.setText(SB.toString());
   }
   
   class MyMouse extends MouseAdapter
   {      
      public void mouseEntered(MouseEvent e)
      {   
         Component c = (Component)e.getSource();
         c.setBackground(Color.WHITE);
         JL1.setText("");
         JL2.setText("");
      }
      
      public void mouseExited(MouseEvent e)
      {   
         Component c = (Component)e.getSource();
         c.setBackground(Color.BLACK);      
      }               
   }
   
   class MyMouse2 extends MouseAdapter
   {
      public void mouseClicked(MouseEvent e)
      {
         JButton a = (JButton)e.getSource();
         if(a.getText().equals("�ʱ�ȭ"))
         {
            JA1.setText(null);
            JA2.setText(null);
            JL1.setText("�ʱ�ȭ�Ǿ����ϴ�");
         }
         else if(a.getText().equals("����"))
         {
            JL1.setText("����Ǿ����ϴ�!!");
         }
         else if(a.getText().equals("�ð�"))
         {
            Calendar cal= Calendar.getInstance();
            
            SimpleDateFormat SDF1 = new SimpleDateFormat("yyyy�� MM�� dd��");
            SimpleDateFormat SDF2 = new SimpleDateFormat("E���� HH�� mm��");      
            
            String Today1 = SDF1.format(cal.getTime());
            String Today2 = SDF2.format(cal.getTime());
         
            JL1.setText(Today1);
            JL2.setText(Today2);
         }
         else if(a.getText().equals("�����߰�"))
         {
        	 JL1.setText("�� �� �����ϴ�!! ");
         }
      }
   }
   
   public MyNote() 
   {   
      setTitle("Jave 3�й� 2014211447 �ȼ�ȣ");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      Container Main = getContentPane();
      Main.setLayout(null);
      
      MyMouse Mouse = new MyMouse();
      MyMouse2 Mouse2 = new MyMouse2();
      MyDialog Dialog = new MyDialog(this, "�޷�");
     
      JPanel JP1 = new JPanel();
      JP1.setSize(150,450);
      JP1.setLayout(null);
      JP1.setBackground(Color.gray);
      JP1.addMouseListener(Mouse);
      
      JPanel JP2 = new JPanel();
      JP2.setBounds(149,0,750,450);
      JP2.setLayout(null);
      JP2.setBackground(Color.white);
      JP2.addMouseListener(Mouse);   
      
      JButton JBt1 = new JButton("����");
      JBt1.setBounds(20, 15, 100, 40);
      JBt1.addMouseListener(Mouse2);
      
      JButton JBt2 = new JButton("�ʱ�ȭ");
      JBt2.setBounds(20, 75, 100, 40);
      JBt2.addMouseListener(Mouse2);
      
      JButton JBt3 = new JButton("�����߰�");
      JBt3.setBounds(20, 135, 100, 40);
      JBt3.addMouseListener(Mouse2);
      
      JButton JBt4 = new JButton("�ð�");
      JBt4.setBounds(20, 195, 100, 40);
      JBt4.addMouseListener(Mouse2);
      
      JButton JBt5 = new JButton("�޷�");
      JBt5.setBounds(20, 255, 100, 40);
      JBt5.addActionListener(new ActionListener() 
      {
         public void actionPerformed(ActionEvent e)
         {
            Dialog.setVisible(true);
         }
      });
      
      JScrollPane JS1 = new JScrollPane(JA1); 
      JS1.setBounds(0,0,300,600);
      
      JScrollPane JS2 = new JScrollPane(JA2);
      JS2.setBounds(300,0,300,600);
    
      JL1.setBounds(20,350,150,30);
      JL1.setForeground(Color.white);
      
      JL2.setBounds(20,370,150,30);
      JL2.setForeground(Color.white);
      
      //���� �г�
      JP1.add(JBt1);
      JP1.add(JBt2);
      JP1.add(JBt3);
      JP1.add(JBt4);
      JP1.add(JBt5);   
      JP1.add(JL1);
      JP1.add(JL2);
      //�������г�
      JP2.add(JS2);
      JP2.add(JS1);
      //����
      Main.add(JP1);
      Main.add(JP2);
   
      setSize(764,450);
      setVisible(true);
   }
   
   public static void main(String[] args)
   {
      new MyNote();
   }

}